import React from 'react'

const Income = () => {
  return (
    <div>
      income
    </div>
  )
}

export default Income
