import React from 'react'

const ResidentManagement = () => {
  return (
    <div>
      ResidentManagement
    </div>
  )
}

export default ResidentManagement
